'use client';
import { useEffect, useState } from "react";

interface Recipe {
  id: string;
  name: string;
  chef: string;
  description: string[];
  ingredients: string[];
  steps: { text: string; image?: string; source?: string }[];
  sourceUrl: string;
  images: { url: string; alt: string; source: string }[];
}

export default function HomePage() {
  const [instruction, setInstruction] = useState("");
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [blobHealth, setBlobHealth] = useState<null | boolean>(null);

  useEffect(() => {
    fetch("/api/blob-health")
      .then((r) => r.json())
      .then((d) => setBlobHealth(d.ok))
      .catch(() => setBlobHealth(false));
  }, []);

  async function handleGenerate() {
    setLoading(true);
    setError("");
    try {
      const rsp = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instruction }),
      });
      if (!rsp.ok) throw new Error(await rsp.text());
      const data = await rsp.json();
      setRecipes(data.recipes || []);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="p-6">
      <header className="flex justify-between mb-4">
        <h1 className="text-3xl font-serif">Fresh Recipes</h1>
        <div className="flex gap-4 items-center">
          <a href="/archive" className="underline">Archive</a>
          <span>Blob: {blobHealth === null ? "…" : blobHealth ? "✅" : "❌"}</span>
        </div>
      </header>
      <div className="flex gap-2 mb-4">
        <input
          value={instruction}
          onChange={(e) => setInstruction(e.target.value)}
          className="border px-2 py-1 flex-1"
          placeholder="e.g. 3 Italian desserts"
        />
        <button
          onClick={handleGenerate}
          disabled={loading}
          className="bg-green-600 text-white px-4 py-2 rounded"
        >
          {loading ? "Generating…" : "Generate"}
        </button>
      </div>
      {error && <p className="text-red-600">{error}</p>}
      <section className="grid gap-4">
        {recipes.map((r) => (
          <article key={r.id} className="border p-4 rounded bg-white shadow">
            <h2 className="text-xl font-bold"><a href={r.sourceUrl} target="_blank">{r.name}</a></h2>
            <p className="italic mb-2">By {r.chef}</p>
            {r.images[0] && <img src={r.images[0].url} alt={r.images[0].alt} className="mb-2"/>}
            {r.description.map((d, i) => <p key={i}>{d}</p>)}
            <h3 className="font-semibold mt-2">Ingredients</h3>
            <ul className="list-disc pl-4">{r.ingredients.map((i, idx) => <li key={idx}>{i}</li>)}</ul>
            <h3 className="font-semibold mt-2">Steps</h3>
            <ol className="list-decimal pl-4">{r.steps.map((s, idx) => <li key={idx}>{s.text}</li>)}</ol>
          </article>
        ))}
      </section>
    </main>
  );
}
