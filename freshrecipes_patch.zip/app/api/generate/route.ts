import OpenAI from "openai";
import { NextRequest } from "next/server";
import { put } from "@vercel/blob";

export const runtime = "nodejs";
export const maxDuration = 60;

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const SYSTEM_PROMPT = `
You return structured JSON (not HTML) for recipes, with real, hotlinkable photo URLs and source links.
Follow this exact schema:

{
  "recipes": [
    {
      "id": "string-unique",
      "name": "Recipe title",
      "chef": "Chef name and short background",
      "description": ["paragraph 1", "paragraph 2", "paragraph 3+"],
      "ingredients": ["..."],
      "steps": [
        { "text": "Step text", "image": "https://...", "source": "https://source-page-for-this-photo" }
      ],
      "sourceUrl": "https://source-recipe-page",
      "images": [
        { "url": "https://...", "alt": "meaningful alt", "source": "https://source-recipe-page-or-photo-page" }
      ]
    }
  ]
}

Rules:
- Use real recipe sources from chefs, publishers, or reputable press; never invent URLs.
- Prefer official or well-established sources (e.g., publisher CDNs, chef sites). Avoid "placeholder", "stock", "example", "unsplash", "lorem", "dummy" images.
- If a step photo exists at the source, include it with its source URL; otherwise omit the step image (do NOT invent).
- The 'source' for each image must be a clickable page that contains that photo or the recipe.
- The JSON must be valid and parseable. No extra commentary.
`;

function isHttpUrl(u?: string) {
  if (!u) return false;
  try {
    const url = new URL(u);
    return url.protocol === "http:" || url.protocol === "https:";
  } catch {
    return false;
  }
}

function looksLikePlaceholder(u: string) {
  const s = u.toLowerCase();
  return (
    s.includes("placeholder") ||
    s.includes("dummy") ||
    s.includes("lorem") ||
    s.includes("example.com") ||
    s.includes("unsplash") ||
    s.includes("via.placeholder") ||
    s.endsWith(".svg")
  );
}

async function isGoodImage(url: string, referer: string): Promise<boolean> {
  if (!isHttpUrl(url) || looksLikePlaceholder(url)) return false;
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 8000);
  try {
    const rsp = await fetch(url, {
      method: "GET",
      redirect: "follow",
      signal: ctrl.signal,
      headers: {
        "User-Agent": "Mozilla/5.0 (compatible; FreshRecipesBot/1.0)",
        Referer: referer,
        Accept: "image/*,*/*;q=0.8",
        Range: "bytes=0-0",
      },
    });
    if (!rsp.ok) return false;
    const ct = rsp.headers.get("content-type") || "";
    if (!ct.startsWith("image/")) return false;
    return true;
  } catch {
    return false;
  } finally {
    clearTimeout(t);
  }
}

function proxy(url: string, origin: string) {
  const u = new URL("/api/img", origin);
  u.searchParams.set("u", url);
  return u.toString();
}

async function verifyAllImages(recipes: any[], origin: string) {
  const referer = origin + "/";
  for (const r of recipes || []) {
    if (Array.isArray(r.images)) {
      const out: any[] = [];
      for (const im of r.images) {
        if (im?.url && (await isGoodImage(im.url, referer))) {
          out.push({ ...im, url: proxy(im.url, origin) });
        }
      }
      r.images = out;
    }
    if (Array.isArray(r.steps)) {
      r.steps = await Promise.all(
        r.steps.map(async (st: any) => {
          if (st?.image && (await isGoodImage(st.image, referer))) {
            return { ...st, image: proxy(st.image, origin) };
          }
          const { image, ...rest } = st || {};
          return rest;
        })
      );
    }
  }
  return recipes;
}

export async function POST(req: NextRequest) {
  try {
    const { instruction } = await req.json();
    if (!instruction) {
      return new Response("Missing instruction", { status: 400 });
    }

    const ai = await client.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4.1",
      temperature: 0.2,
      max_tokens: 4000,
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: instruction },
      ],
      response_format: { type: "json_object" },
    });

    const txt = ai.choices?.[0]?.message?.content || "{}";
    let data: any;
    try {
      data = JSON.parse(txt);
    } catch {
      return new Response("Invalid JSON", { status: 502 });
    }

    if (!Array.isArray(data.recipes)) data.recipes = [];

    const origin = req.nextUrl.origin;
    data.recipes = await verifyAllImages(data.recipes, origin);

    // save as blob HTML
    const html = `<html><body><pre>${JSON.stringify(data, null, 2)}</pre></body></html>`;
    const slug = Date.now();
    await put(`recipes/${slug}.html`, new Blob([html]), {
      access: "public",
      token: process.env.BLOB_READ_WRITE_TOKEN,
    });

    return new Response(JSON.stringify(data), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (err: any) {
    return new Response(err.message || "Server error", { status: 500 });
  }
}
