import { NextRequest } from "next/server";

export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  const u = req.nextUrl.searchParams.get("u");
  if (!u || !(u.startsWith("http://") || u.startsWith("https://"))) {
    return new Response("Bad URL", { status: 400 });
  }
  try {
    const rsp = await fetch(u, {
      headers: {
        "User-Agent": "Mozilla/5.0 (compatible; FreshRecipesBot/1.0)",
        Accept: "image/*,*/*;q=0.8",
      },
    });
    if (!rsp.ok) return new Response("Fetch failed", { status: rsp.status });
    const ct = rsp.headers.get("content-type") || "image/jpeg";
    return new Response(rsp.body, {
      headers: {
        "Content-Type": ct,
        "Cache-Control": "public, max-age=86400",
      },
    });
  } catch (e: any) {
    return new Response("Proxy error", { status: 500 });
  }
}
