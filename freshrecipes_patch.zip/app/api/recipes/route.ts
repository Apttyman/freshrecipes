import { list } from "@vercel/blob";

export const runtime = "nodejs";

export async function GET() {
  try {
    const { blobs } = await list({
      prefix: "recipes/",
      token: process.env.BLOB_READ_WRITE_TOKEN,
    });
    blobs.sort((a, b) => (a.uploadedAt < b.uploadedAt ? 1 : -1));
    return new Response(JSON.stringify(blobs), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (err: any) {
    return new Response("Error listing blobs", { status: 500 });
  }
}
