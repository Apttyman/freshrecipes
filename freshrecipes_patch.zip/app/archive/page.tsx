'use client';
import { useEffect, useState } from "react";

interface BlobItem {
  pathname: string;
  uploadedAt: string;
  size: number;
  url: string;
}

export default function ArchivePage() {
  const [items, setItems] = useState<BlobItem[]>([]);
  const [error, setError] = useState("");

  useEffect(() => {
    fetch("/api/recipes", { cache: "no-store" })
      .then((r) => r.json())
      .then(setItems)
      .catch((e) => setError(e.message));
  }, []);

  return (
    <main className="p-6">
      <h1 className="text-2xl mb-4">Archive</h1>
      {error && <p className="text-red-600">{error}</p>}
      <ul className="space-y-2">
        {items.map((b) => (
          <li key={b.pathname} className="border p-2 rounded">
            <a href={b.url} target="_blank" className="underline">{b.pathname}</a>
            <div className="text-sm text-gray-600">{new Date(b.uploadedAt).toLocaleString()} — {Math.round(b.size/1024)} KB</div>
          </li>
        ))}
      </ul>
    </main>
  );
}
